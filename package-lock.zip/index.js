const { Client, GatewayIntentBits, EmbedBuilder } = require('discord.js');
const fs = require('fs');

// 🔴 นำรหัส Token ของบอทคุณมาใส่ในเครื่องหมาย ' ' ด้านล่างนี้
const TOKEN = 'MTUzNjY0ODQ3NTgzNDQ1ODE2Mg.GucUlm.n6cgrCu5PEgxXAskZdMq8snQdJOG-lUxmC_2hE';

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
    ]
});

// ไฟล์สำหรับเก็บข้อมูลบัญชีของกิลด์
const dbPath = './economy.json';

function loadDB() {
    if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, '{}');
    return JSON.parse(fs.readFileSync(dbPath));
}

function saveDB(data) {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 4));
}

client.once('ready', () => {
    console.log(`บอท ${client.user.tag} พร้อมเปิดบ่อนและแจกฟรุ้งฟริ้งแล้ว! 🎲✨`);
});

client.on('messageCreate', (message) => {
    if (message.author.bot) return;
    
    const args = message.content.trim().split(/ +/);
    const command = args.shift().toLowerCase();
    
    let db = loadDB();
    const userId = message.author.id;

    if (!db[userId]) {
        db[userId] = { balance: 0, lastDaily: 0, lastHunt: 0 };
    }

    // ==========================================
    // 📊 ระบบสุ่มสเตตัส (!status หรือ !สเตตัส)
    // ==========================================
    if (command === '!status' || command === '!สเตตัส') {
        const str = Math.floor(Math.random() * 100) + 1;
        const agi = Math.floor(Math.random() * 100) + 1;
        const int = Math.floor(Math.random() * 100) + 1;
        const luk = Math.floor(Math.random() * 100) + 1;

        const totalStat = str + agi + int + luk;
        let note = "";

        if (totalStat >= 360) note = "👑 พระเอกต่างโลกชัดๆ! บัคเกมแน่ๆ ไปตบจอมมารตั้งแต่วันแรกเลยไป!";
        else if (totalStat <= 100) note = "💀 สไลม์หน้าเมืองยังเก่งกว่าคุณ... แนะนำให้ไปโดนรถบรรทุกชนอีกรอบนะ";
        else if (luk >= 95) note = "✨ บุตรแห่งพระเจ้า! กาชาปองไม่เคยเกลือ เดินเตะฝุ่นก็เจอดาบศักดิ์สิทธิ์!";
        else if (luk <= 10) note = "😭 ดวงซวยระดับจักรวาล... ระวังเดินสะดุดยอดหญ้าตายนะ";
        else if (int >= 90 && str <= 30) note = "🧙‍♂️ มหาปราชญ์ผู้เปราะบาง... ร่ายเวทซะเท่ แต่โดนลมอ่อนๆ พัดก็ล้มแล้ว";
        else if (str >= 90 && int <= 30) note = "🦍 มีแต่กล้ามเนื้อไม่มีสมอง! เอาหัวโขกกำแพงแทนการเปิดประตูชัวร์";
        else if (agi >= 95) note = "⚡ ความเร็วแสง! วิ่งหนีมอนสเตอร์ (และวิ่งหนีหนี้) ไวที่สุดในปฐพี!";
        else if (str >= 85 && agi >= 85) note = "🥷 นักฆ่าเงามืด! พุ่งเข้าไปฟาดหน้าจอมมารแล้วจากไปอย่างรวดเร็ว";
        else if (str <= 20 && agi <= 20) note = "🐢 ช้าแถมอ่อนแอ... อาชีพที่เหมาะกับคุณคือ 'ก้อนหินประดับดันเจี้ยน'";
        else if (str === 69 || agi === 69 || int === 69 || luk === 69) note = "😏 เลข 69 สวยนะเราน่ะ... ดูทรงน่าจะถนัดวิชาแปลกๆ (ห๊ะ!)";
        else if (str >= 80) note = "💪 พี่กล้ามโต! แบกเพื่อนลงดันเจี้ยนได้สบายๆ";
        else if (int >= 80) note = "🧠 จอมเวทมันสมอง! หวังว่าตอนร่ายเวทจะไม่ลืมบทนะ";
        else if (agi >= 80) note = "🏃 สายพลิ้ว! หลบเก่งจนมอนสเตอร์หมั่นไส้";
        else if (luk >= 80) note = "🍀 คนดวงดี! ฝากกดสุ่มกาชาแทนเพื่อนหน่อยสิ";
        else if (luk <= 30) note = "🧂 กลิ่นความเกลือลอยมาแต่ไกล...";
        else note = "🧑‍🌾 ชาวบ้าน A ผู้ทรงเกียรติ... ไปทำฟาร์มปลูกผักชิลๆ ดีกว่านะ";

        const statusEmbed = new EmbedBuilder()
            .setColor('#FFD700')
            .setTitle(`📊 ใบประเมินสเตตัสของ ${message.author.username}`)
            .setDescription(`หลังจากโดนรถบรรทุกชน นี่คือพลังแฝงของคุณ!\n\n**บทสรุป:** ${note}`)
            .addFields(
                { name: '💪 พละกำลัง (STR)', value: `**${str}**/100`, inline: true },
                { name: '🏃 ความเร็ว (AGI)', value: `**${agi}**/100`, inline: true },
                { name: '🧠 เวทมนตร์ (INT)', value: `**${int}**/100`, inline: true },
                { name: '🍀 โชคชะตา (LUK)', value: `**${luk}**/100`, inline: true }
            )
            .setThumbnail(message.author.displayAvatarURL())
            .setFooter({ text: 'ออกใบรับรองโดย สมาคมนักผจญภัย' });

        return message.reply({ embeds: [statusEmbed] });
    }

    // ==========================================
    // 🪙 เช็คเงิน และ เงินเดือน (!bal, !money, !daily)
    // ==========================================
    if (command === '!bal' || command === '!money') {
        const balEmbed = new EmbedBuilder()
            .setColor('#00FF00')
            .setDescription(`💰 **${message.author.username}** ตอนนี้คุณมีเงิน **${db[userId].balance}** ฟรุ้งฟริ้ง`);
        return message.reply({ embeds: [balEmbed] });
    }

    if (command === '!daily') {
        const cooldown = 24 * 60 * 60 * 1000;
        const timeNow = Date.now();
        const lastDaily = db[userId].lastDaily;

        if (timeNow - lastDaily < cooldown) {
            const timeLeft = Math.floor((cooldown - (timeNow - lastDaily)) / (60 * 60 * 1000));
            return message.reply(`⏳ ใจเย็นวัยรุ่น! คุณรับเงินเดือนไปแล้ว ต้องรออีก **${timeLeft} ชั่วโมง** ถึงจะรับได้ใหม่`);
        }

        db[userId].balance += 500;
        db[userId].lastDaily = timeNow;
        saveDB(db);

        return message.reply(`🎉 รับเงินเดือนสำเร็จ! คุณได้รับ **500 ฟรุ้งฟริ้ง** ✨ (ยอดรวม: ${db[userId].balance})`);
    }

    // ==========================================
    // ⚔️ ออกล่ามอนสเตอร์ (!hunt หรือ !ล่า)
    // ==========================================
    if (command === '!hunt' || command === '!ล่า') {
        const cooldown = 60 * 1000;
        const timeNow = Date.now();
        if (!db[userId].lastHunt) db[userId].lastHunt = 0;

        if (timeNow - db[userId].lastHunt < cooldown) {
            const timeLeft = Math.ceil((cooldown - (timeNow - db[userId].lastHunt)) / 1000);
            return message.reply(`⏳ เหนื่อยหอบอยู่! รออีก **${timeLeft} วินาที** ค่อยออกไปล่าใหม่นะ`);
        }

        const isWin = Math.random() < 0.5;
        const amount = Math.floor(Math.random() * (1000 - 100 + 1)) + 100;

        const winScenarios = [
            "ไปตีสไลม์หน้าเมืองแล้วบังเอิญเจอก้อนทองคำแท่งดรอป", "ช่วยแมวของหัวหน้าหมู่บ้านลงจากต้นไม้ ได้รับรางวัลอย่างงาม",
            "ปราบบอสก็อบลินที่ขโมยเสบียงหมู่บ้านสำเร็จ", "ขุดเจอสมบัติโจรสลัดที่ชายหาดลับ",
            "ตกปลาแต่ดันตกได้หีบสมบัติโบราณแทน", "สู้กับมังกรเพลิงและแอบจิ๊กเกล็ดมันมาขายได้ราคาดี",
            "รับจ้างเป็นบอดี้การ์ดให้พ่อค้าคาราวานจนจบเส้นทาง", "ไปสำรวจดันเจี้ยนร้างแล้วเจอถุงเงินของใครไม่รู้ตกอยู่",
            "เด็ดสมุนไพรหายากไปขายให้ร้านปรุงยา", "ชนะการประลองดาบในงานเทศกาลเมือง",
            "ช่วยคุณยายถือของข้ามถนน ยายเลยให้ค่าขนมมา", "ล่าหมูป่ากลายพันธุ์ เอาเนื้อไปขายโรงเตี๊ยมคนหน้าตาดี",
            "ไขปริศนาของสฟิงซ์ได้สำเร็จ สฟิงซ์เลยจ่ายค่าผ่านทางให้", "ปราบนางเงือกไซเรนที่หลอกชาวประมง",
            "เก็บอาวุธระดับ SSR ที่ตกอยู่กลางป่าไปขายร้านของเก่า", "ไปทวงหนี้ให้มาเฟียต่างโลก ได้ส่วนแบ่งซะงั้น",
            "เจอจุดฟาร์มบัคในดันเจี้ยน ตีมอนสเตอร์ดรอปเงินรัวๆ", "ร้องเพลงเปิดหมวกหน้าลานน้ำพุ มีคนใจดีโยนเงินให้",
            "ล่าหมาป่าหิมะ เอาขนไปขายให้ช่างตัดเสื้อระดับพระราชวัง", "แอบขโมยไข่มังกรไปขายตลาดมืด (รอดมาได้ไงเนี่ย!)",
            "ช่วยเจ้าหญิงที่ถูกโจรลักพาตัว พระราชาเลยตบรางวัลให้", "ขายตั๋วคอนเสิร์ตนักกวีชื่อดังผีหลอก (แอบโก่งราคา)",
            "รับเหมาทำความสะอาดกิลด์นักผจญภัยจนเงาวับ", "บังเอิญไปเตะหินแล้วเจอแร่โอริคัลคุม",
            "ปราบบอสลับที่โผล่มาตอนเที่ยงคืนได้แบบฟลุคๆ", "เป็นนายแบบ/นางแบบให้จิตรกรเอกของเมือง",
            "รับจ้างแบกของขึ้นภูเขาไฟมรณะรอดกลับมาได้", "สกัดจับโจรขโมยชุดชั้นใน ได้รางวัลนำจับจากกรมตำรวจ",
            "เจอสูตรอาหารลับในซากปรักหักพัง เอาไปขายให้มาสเตอร์", "ฟาร์มมอนสเตอร์จนเลเวลอัป พระเจ้าระบบเลยโอนเงินรางวัลให้"
        ];

        const loseScenarios = [
            "ไปตีสไลม์แต่สะดุดก้อนหินล้ม ดาบหัก ต้องจ่ายค่าซ่อม", "โดนมังกรพ่นไฟใส่ ชุดเกราะไหม้เกรียม ต้องซื้อใหม่",
            "โดนก็อบลินล้วงกระเป๋าตอนเผลอหลับใต้ต้นไม้", "โดนพ่อค้าหน้าเลือดหลอกขายแผนที่สมบัติปลอม",
            "เดินตกหลุมพรางในดันเจี้ยน เสียค่ารักษาพยาบาล", "ไปท้าสู้กับอัศวินศักดิ์สิทธิ์แล้วแพ้ยับ โดนไถเงิน",
            "กินเห็ดพิษในป่า ท้องร่วงหนัก ต้องจ่ายค่ายาถอนพิษ", "โดนตำรวจเวทมนตร์จับข้อหาใช้สกิลเสียงดังรบกวนชาวบ้าน",
            "แวะบ่อนคาสิโนเมืองหน้า โดนต้มตุ๋นจนหมดตัว", "เช่าม้าไปทำเควสต์ แต่ม้าหนีเตลิด ต้องจ่ายค่าปรับให้เจ้าของ",
            "รับเควสต์ปราบจอมมาร แต่ดันไปพังบ้านชาวบ้านพัง โดนฟ้องร้อง", "อาวุธหลุดมือตอนสู้กับบอส ปลิวตกกระทะลาวา",
            "โดนแม่มดหลอกขายยาโพชั่นหมดอายุ ท้องเสียไป 3 วัน", "ปาร์ตี้แตก โดนเพื่อนในทีมเชิดเงินหนี",
            "ไปล่าหมีป่า แต่โดนหมีวิ่งไล่จนต้องโยนถุงเงินทิ้งเพื่อเอาชีวิตรอด", "เดินเหม่อลอย ชนรูปปั้นเทพเจ้าแตก ต้องจ่ายค่าเสียหาย",
            "โดนแก๊งอันธพาลดักปล้นหน้าลานกว้าง", "จ่ายค่าผ่านทางให้โทรลล์ใต้สะพานแบบขูดเลือดขูดเนื้อ",
            "เผลอหลับใต้ต้นไม้ โดนลิงปีศาจขโมยเหรียญไปหมด", "โดนแฟรี่ตัวแสบเสกให้เงินในกระเป๋ากลายเป็นใบไม้",
            "เมาเหล้าที่โรงเตี๊ยม เลี้ยงทุกคนทั้งร้าน ตื่นมาบิลบานตะไท", "ซื้อดาบในตลาดมืด โดนย้อมแมวเอาพลาสติกมาขาย",
            "โดนจอมปีศาจขู่กรรโชกทรัพย์หน้าปากซอย", "ทำสร้อยคอเวทมนตร์หล่นหายระหว่างสู้กับสไลม์",
            "วิ่งหนีซอมบี้จนรองเท้าขาด ต้องซื้อคู่ใหม่ระดับพรีเมียม", "เผลอไปเหยียบหางมังกร โดนเรียกค่าทำขวัญบานตะไท",
            "รับเควสต์ส่งของแต่ทำของพัง ต้องชดใช้ค่าเสียหาย", "โดนระบบเกมหักภาษีรายได้ประจำเดือนแบบงงๆ",
            "เผลอเปย์เงินให้นักบวชสาว(ปลอม)ในดิสคอร์ดกิลด์", "โดนจับข้อหาล่ามอนสเตอร์สงวนในเขตอนุรักษ์ป่าไม้"
        ];

        db[userId].lastHunt = timeNow;
        let resultMessage = "";

        if (isWin) {
            const scenario = winScenarios[Math.floor(Math.random() * winScenarios.length)];
            db[userId].balance += amount;
            resultMessage = `⚔️ **ออกล่าสำเร็จ!**\n> ${scenario}\n🎉 ได้รับเงิน **${amount} ฟรุ้งฟริ้ง!** (ยอดรวม: ${db[userId].balance})`;
        } else {
            const scenario = loseScenarios[Math.floor(Math.random() * loseScenarios.length)];
            db[userId].balance = Math.max(0, db[userId].balance - amount);
            resultMessage = `💀 **ภารกิจล้มเหลว!**\n> ${scenario}\n💸 เสียเงินไป **${amount} ฟรุ้งฟริ้ง!** (ยอดคงเหลือ: ${db[userId].balance})`;
        }

        saveDB(db);

        const huntEmbed = new EmbedBuilder()
            .setColor(isWin ? '#00FF00' : '#FF0000')
            .setAuthor({ name: `${message.author.username} ออกผจญภัย...`, iconURL: message.author.displayAvatarURL() })
            .setDescription(resultMessage);

        return message.reply({ embeds: [huntEmbed] });
    }

    // ==========================================
    // 🎲 เสี่ยงโชค/มินิเกม (!cf และ !slots)
    // ==========================================
    if (command === '!cf' || command === '!coinflip') {
        const choice = args[0]?.toLowerCase(); 
        const bet = parseInt(args[1]);

        if (!choice || (choice !== 'หัว' && choice !== 'ก้อย')) return message.reply('❌ วิธีเล่น: พิมพ์ `!cf หัว <เงิน>` หรือ `!cf ก้อย <เงิน>`');
        if (!bet || bet <= 0 || isNaN(bet)) return message.reply('❌ ใส่จำนวนเงินแทงที่ถูกต้องด้วยครับ');
        if (db[userId].balance < bet) return message.reply('💸 ฟรุ้งฟริ้งไม่พอแทง! ไปหาเงินมาก่อน');

        const result = Math.random() < 0.5 ? 'หัว' : 'ก้อย';

        if (choice === result) {
            db[userId].balance += bet; 
            saveDB(db);
            return message.reply(`🪙 เหรียญออก **[ ${result} ]** !! 🎉 คุณทายถูก! ได้รับเงินเพิ่ม **${bet} ฟรุ้งฟริ้ง** (ยอดรวม: ${db[userId].balance})`);
        } else {
            db[userId].balance -= bet; 
            saveDB(db);
            return message.reply(`🪙 เหรียญออก **[ ${result} ]** !! 😭 คุณทายผิด! เสียเงินไป **${bet} ฟรุ้งฟริ้ง** (ยอดคงเหลือ: ${db[userId].balance})`);
        }
    }

    if (command === '!slots') {
        const bet = parseInt(args[0]);
        if (!bet || bet <= 0 || isNaN(bet)) return message.reply('❌ วิธีเล่น: พิมพ์ `!slots <จำนวนเงิน>`');
        if (db[userId].balance < bet) return message.reply('💸 ฟรุ้งฟริ้งไม่พอลงตู้สล็อต!');

        // เพิ่มเชอร์รี่ (🍒) เข้ามาเป็นสัญลักษณ์ที่ 6 เพื่อลดโอกาสถูกรางวัล
        const items = ['🎰', '💎', '👑', '7️⃣', '💣', '🍒'];
        const reel1 = items[Math.floor(Math.random() * items.length)];
        const reel2 = items[Math.floor(Math.random() * items.length)];
        const reel3 = items[Math.floor(Math.random() * items.length)];

        let resultText = "";

        if (reel1 === reel2 && reel2 === reel3) {
            const reward = bet * 5;
            db[userId].balance += reward;
            resultText = `🎉 **JACKPOT!!** ออกเหมือนกันหมด! คุณได้รับเงิน **${reward} ฟรุ้งฟริ้ง!** (5 เท่า)`;
        } else if (reel1 === reel2 || reel2 === reel3 || reel1 === reel3) {
            const reward = bet * 2;
            db[userId].balance += reward;
            resultText = `✨ **เกือบเทพ!** ออกเหมือนกัน 2 ช่อง! คุณได้รับเงิน **${reward} ฟรุ้งฟริ้ง!** (2 เท่า)`;
        } else {
            db[userId].balance -= bet;
            resultText = `💸 **เกลือกระจาย!** ไม่ตรงกันเลย คุณเสียเงินไป **${bet} ฟรุ้งฟริ้ง**`;
        }

        saveDB(db);

        const slotEmbed = new EmbedBuilder()
            .setColor('#E74C3C')
            .setTitle('🎰 ตู้สล็อตสมาคมนักผจญภัย')
            .setDescription(`[ ${reel1} | ${reel2} | ${reel3} ]\n\n${resultText}\n💰 ยอดคงเหลือ: **${db[userId].balance} ฟรุ้งฟริ้ง**`);

        return message.reply({ embeds: [slotEmbed] });
    }

    // ==========================================
    // 🤝 สังคมและการโอนเงิน (!pay และ !rob)
    // ==========================================
    if (command === '!pay') {
        const target = message.mentions.users.first();
        const amount = parseInt(args[1]);

        if (!target) return message.reply('❌ คุณต้องแท็กเพื่อนที่ต้องการโอนเงินให้ด้วย (เช่น `!pay @ชื่อเพื่อน 100`)');
        if (target.id === userId) return message.reply('❌ โอนเงินให้ตัวเองไม่ได้เว้ย!');
        if (!amount || amount <= 0 || isNaN(amount)) return message.reply('❌ ใส่จำนวนเงินที่ถูกต้องด้วย');
        if (db[userId].balance < amount) return message.reply('💸 ฟรุ้งฟริ้งไม่พอ! ไปทำงานหาเงินก่อนไป');

        if (!db[target.id]) db[target.id] = { balance: 0, lastDaily: 0, lastHunt: 0 };

        db[userId].balance -= amount;
        db[target.id].balance += amount;
        saveDB(db);

        return message.reply(`💸 **${message.author.username}** ได้โอนเงิน **${amount} ฟรุ้งฟริ้ง** ให้กับ **${target.username}** เรียบร้อยแล้ว!`);
    }

    if (command === '!rob') {
        const target = message.mentions.users.first();
        if (!target) return message.reply('❌ จะปล้นใคร แท็กชื่อด้วย! (เช่น `!rob @ชื่อเพื่อน`)');
        if (target.id === userId) return message.reply('❌ บ้าไปแล้ว ปล้นตัวเองทำไม!');
        
        // เช็คว่าเป้าหมายมีเงินให้ปล้นไหม (ขั้นต่ำ 100) และคนปล้นมีเงินพอจ่ายค่าปรับไหม (ขั้นต่ำ 50)
        if (!db[target.id] || db[target.id].balance < 100) return message.reply('❌ เป้าหมายจนเกินไป ปล้นไปก็ไม่ได้อะไร ปล่อยเขาไปเถอะ...');
        if (db[userId].balance < 50) return message.reply('❌ คุณต้องมีฟรุ้งฟริ้งติดตัวอย่างน้อย 50 เพื่อเป็นค่าปรับเผื่อโดนจับได้!');

        const chance = Math.random();
        
        if (chance > 0.6) {
            // สำเร็จ! ขโมย 20% - 95% ของเงินเป้าหมาย
            const percentWin = Math.floor(Math.random() * (95 - 20 + 1)) + 20;
            const stolenAmount = Math.floor((db[target.id].balance * percentWin) / 100);

            db[target.id].balance -= stolenAmount;
            db[userId].balance += stolenAmount;
            saveDB(db);

            return message.reply(`🥷 **สำเร็จ!** คุณแอบขโมยถุงเงินของ ${target.username} มาได้ **${stolenAmount} ฟรุ้งฟริ้ง!** (${percentWin}% ของเป้าหมาย) 🏃‍♂️💨`);
        } else {
            // ล้มเหลว! โดนจับปรับ 10% - 50% ของเงินตัวเอง
            const percentLose = Math.floor(Math.random() * (50 - 10 + 1)) + 10;
            const lostAmount = Math.floor((db[userId].balance * percentLose) / 100);

            db[userId].balance -= lostAmount;
            saveDB(db);

            return message.reply(`🚨 **โดนจับได้!** ยามหน้าประตูเมืองจับคุณขังคุก โดนยึดค่าปรับไป **${lostAmount} ฟรุ้งฟริ้ง** (${percentLose}% ของเงินคุณ) สมน้ำหน้า! 😂`);
        }
    }
});

client.login(TOKEN);